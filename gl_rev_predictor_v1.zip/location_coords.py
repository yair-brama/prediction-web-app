"""
location_coords.py
------------------
Lookup table mapping Loc Number (int) -> geographic coordinates.

HOW TO FILL THIS IN
-------------------
1. Replace every placeholder 0.0 / 0.0 pair with the actual latitude and
   longitude of that store location.

2. Coordinates must be in decimal degrees:
     Latitude  : positive = North, negative = South  (e.g. 40.7128 for NYC)
     Longitude : positive = East,  negative = West   (US stores are negative,
                                                       e.g. -74.0060 for NYC)

3. The "name" field is optional but helps with debugging and UI display.
   Replace "Store N" with a human-readable label if you have one.

4. RECOMMENDED ways to find coordinates:
     - Google Maps : right-click any point on the map -> the first line shown
                     is "lat, lon" (e.g. "40.7128, -74.0060")
     - Your internal store / HR database
     - A geocoding API (geopy, googlemaps, positionstack) if you only have
       street addresses

5. Stores whose coordinates are still 0.0 / 0.0 will show a warning in the
   app when weather auto-fill is attempted. They do NOT break the app.

6. Do NOT commit real store addresses or PII to a public repository.
"""

# Sentinel values used to detect un-filled placeholders.
# (0.0, 0.0) is in the Gulf of Guinea -- no US retail store is there.
# Do NOT change these values.
_PLACEHOLDER_LAT = 0.0
_PLACEHOLDER_LON = 0.0


LOCATION_COORDS: dict[int, dict] = {
    # <Loc Number>: {"lat": <float>, "lon": <float>, "name": "<str>"},
    # Replace 0.0 / 0.0 with real coordinates.

    4:   {"lat": 33.7544657, "lon": -84.3898151, "name": "Store 4"},
    5:   {"lat": 0.0, "lon": 0.0, "name": "Store 5"},
    8:   {"lat": 0.0, "lon": 0.0, "name": "Store 8"},
    10:  {"lat": 0.0, "lon": 0.0, "name": "Store 10"},
    11:  {"lat": 0.0, "lon": 0.0, "name": "Store 11"},
    12:  {"lat": 0.0, "lon": 0.0, "name": "Store 12"},
    13:  {"lat": 0.0, "lon": 0.0, "name": "Store 13"},
    14:  {"lat": 0.0, "lon": 0.0, "name": "Store 14"},
    15:  {"lat": 0.0, "lon": 0.0, "name": "Store 15"},
    16:  {"lat": 0.0, "lon": 0.0, "name": "Store 16"},
    17:  {"lat": 0.0, "lon": 0.0, "name": "Store 17"},
    18:  {"lat": 0.0, "lon": 0.0, "name": "Store 18"},
    20:  {"lat": 0.0, "lon": 0.0, "name": "Store 20"},
    21:  {"lat": 0.0, "lon": 0.0, "name": "Store 21"},
    22:  {"lat": 0.0, "lon": 0.0, "name": "Store 22"},
    23:  {"lat": 0.0, "lon": 0.0, "name": "Store 23"},
    24:  {"lat": 0.0, "lon": 0.0, "name": "Store 24"},
    25:  {"lat": 0.0, "lon": 0.0, "name": "Store 25"},
    26:  {"lat": 0.0, "lon": 0.0, "name": "Store 26"},
    27:  {"lat": 0.0, "lon": 0.0, "name": "Store 27"},
    28:  {"lat": 0.0, "lon": 0.0, "name": "Store 28"},
    29:  {"lat": 0.0, "lon": 0.0, "name": "Store 29"},
    31:  {"lat": 0.0, "lon": 0.0, "name": "Store 31"},
    32:  {"lat": 0.0, "lon": 0.0, "name": "Store 32"},
    33:  {"lat": 0.0, "lon": 0.0, "name": "Store 33"},
    34:  {"lat": 0.0, "lon": 0.0, "name": "Store 34"},
    35:  {"lat": 0.0, "lon": 0.0, "name": "Store 35"},
    36:  {"lat": 0.0, "lon": 0.0, "name": "Store 36"},
    38:  {"lat": 0.0, "lon": 0.0, "name": "Store 38"},
    39:  {"lat": 0.0, "lon": 0.0, "name": "Store 39"},
    42:  {"lat": 0.0, "lon": 0.0, "name": "Store 42"},
    43:  {"lat": 0.0, "lon": 0.0, "name": "Store 43"},
    44:  {"lat": 0.0, "lon": 0.0, "name": "Store 44"},
    45:  {"lat": 0.0, "lon": 0.0, "name": "Store 45"},
    47:  {"lat": 0.0, "lon": 0.0, "name": "Store 47"},
    49:  {"lat": 0.0, "lon": 0.0, "name": "Store 49"},
    50:  {"lat": 0.0, "lon": 0.0, "name": "Store 50"},
    51:  {"lat": 0.0, "lon": 0.0, "name": "Store 51"},
    52:  {"lat": 0.0, "lon": 0.0, "name": "Store 52"},
    53:  {"lat": 0.0, "lon": 0.0, "name": "Store 53"},
    54:  {"lat": 0.0, "lon": 0.0, "name": "Store 54"},
    55:  {"lat": 0.0, "lon": 0.0, "name": "Store 55"},
    56:  {"lat": 0.0, "lon": 0.0, "name": "Store 56"},
    57:  {"lat": 0.0, "lon": 0.0, "name": "Store 57"},
    58:  {"lat": 0.0, "lon": 0.0, "name": "Store 58"},
    59:  {"lat": 0.0, "lon": 0.0, "name": "Store 59"},
    60:  {"lat": 0.0, "lon": 0.0, "name": "Store 60"},
    61:  {"lat": 0.0, "lon": 0.0, "name": "Store 61"},
    62:  {"lat": 0.0, "lon": 0.0, "name": "Store 62"},
    63:  {"lat": 0.0, "lon": 0.0, "name": "Store 63"},
    64:  {"lat": 0.0, "lon": 0.0, "name": "Store 64"},
    66:  {"lat": 0.0, "lon": 0.0, "name": "Store 66"},
    67:  {"lat": 0.0, "lon": 0.0, "name": "Store 67"},
    68:  {"lat": 0.0, "lon": 0.0, "name": "Store 68"},
    69:  {"lat": 0.0, "lon": 0.0, "name": "Store 69"},
    70:  {"lat": 0.0, "lon": 0.0, "name": "Store 70"},
    71:  {"lat": 0.0, "lon": 0.0, "name": "Store 71"},
    72:  {"lat": 0.0, "lon": 0.0, "name": "Store 72"},
    74:  {"lat": 0.0, "lon": 0.0, "name": "Store 74"},
    75:  {"lat": 0.0, "lon": 0.0, "name": "Store 75"},
    76:  {"lat": 0.0, "lon": 0.0, "name": "Store 76"},
    77:  {"lat": 0.0, "lon": 0.0, "name": "Store 77"},
    78:  {"lat": 0.0, "lon": 0.0, "name": "Store 78"},
    79:  {"lat": 0.0, "lon": 0.0, "name": "Store 79"},
    80:  {"lat": 0.0, "lon": 0.0, "name": "Store 80"},
    81:  {"lat": 0.0, "lon": 0.0, "name": "Store 81"},
    82:  {"lat": 0.0, "lon": 0.0, "name": "Store 82"},
    83:  {"lat": 0.0, "lon": 0.0, "name": "Store 83"},
    84:  {"lat": 0.0, "lon": 0.0, "name": "Store 84"},
    85:  {"lat": 0.0, "lon": 0.0, "name": "Store 85"},
    86:  {"lat": 0.0, "lon": 0.0, "name": "Store 86"},
    87:  {"lat": 0.0, "lon": 0.0, "name": "Store 87"},
    88:  {"lat": 0.0, "lon": 0.0, "name": "Store 88"},
    89:  {"lat": 0.0, "lon": 0.0, "name": "Store 89"},
    90:  {"lat": 0.0, "lon": 0.0, "name": "Store 90"},
    91:  {"lat": 0.0, "lon": 0.0, "name": "Store 91"},
    92:  {"lat": 0.0, "lon": 0.0, "name": "Store 92"},
    93:  {"lat": 0.0, "lon": 0.0, "name": "Store 93"},
    94:  {"lat": 0.0, "lon": 0.0, "name": "Store 94"},
    95:  {"lat": 0.0, "lon": 0.0, "name": "Store 95"},
    96:  {"lat": 0.0, "lon": 0.0, "name": "Store 96"},
    97:  {"lat": 0.0, "lon": 0.0, "name": "Store 97"},
    98:  {"lat": 0.0, "lon": 0.0, "name": "Store 98"},
    99:  {"lat": 0.0, "lon": 0.0, "name": "Store 99"},
    100: {"lat": 0.0, "lon": 0.0, "name": "Store 100"},
    101: {"lat": 0.0, "lon": 0.0, "name": "Store 101"},
    102: {"lat": 0.0, "lon": 0.0, "name": "Store 102"},
    103: {"lat": 0.0, "lon": 0.0, "name": "Store 103"},
    104: {"lat": 0.0, "lon": 0.0, "name": "Store 104"},
    105: {"lat": 0.0, "lon": 0.0, "name": "Store 105"},
    106: {"lat": 0.0, "lon": 0.0, "name": "Store 106"},
    107: {"lat": 0.0, "lon": 0.0, "name": "Store 107"},
    108: {"lat": 0.0, "lon": 0.0, "name": "Store 108"},
    109: {"lat": 0.0, "lon": 0.0, "name": "Store 109"},
    110: {"lat": 0.0, "lon": 0.0, "name": "Store 110"},
    111: {"lat": 0.0, "lon": 0.0, "name": "Store 111"},
    112: {"lat": 0.0, "lon": 0.0, "name": "Store 112"},
    113: {"lat": 0.0, "lon": 0.0, "name": "Store 113"},
    114: {"lat": 0.0, "lon": 0.0, "name": "Store 114"},
    115: {"lat": 0.0, "lon": 0.0, "name": "Store 115"},
    116: {"lat": 0.0, "lon": 0.0, "name": "Store 116"},
    117: {"lat": 0.0, "lon": 0.0, "name": "Store 117"},
    118: {"lat": 0.0, "lon": 0.0, "name": "Store 118"},
    119: {"lat": 0.0, "lon": 0.0, "name": "Store 119"},
    120: {"lat": 0.0, "lon": 0.0, "name": "Store 120"},
    121: {"lat": 0.0, "lon": 0.0, "name": "Store 121"},
    122: {"lat": 0.0, "lon": 0.0, "name": "Store 122"},
    124: {"lat": 0.0, "lon": 0.0, "name": "Store 124"},
    125: {"lat": 0.0, "lon": 0.0, "name": "Store 125"},
    126: {"lat": 0.0, "lon": 0.0, "name": "Store 126"},
    127: {"lat": 0.0, "lon": 0.0, "name": "Store 127"},
    128: {"lat": 0.0, "lon": 0.0, "name": "Store 128"},
    129: {"lat": 0.0, "lon": 0.0, "name": "Store 129"},
    130: {"lat": 0.0, "lon": 0.0, "name": "Store 130"},
    131: {"lat": 0.0, "lon": 0.0, "name": "Store 131"},
    132: {"lat": 0.0, "lon": 0.0, "name": "Store 132"},
    133: {"lat": 0.0, "lon": 0.0, "name": "Store 133"},
    134: {"lat": 0.0, "lon": 0.0, "name": "Store 134"},
    135: {"lat": 0.0, "lon": 0.0, "name": "Store 135"},
    136: {"lat": 0.0, "lon": 0.0, "name": "Store 136"},
    137: {"lat": 0.0, "lon": 0.0, "name": "Store 137"},
    138: {"lat": 0.0, "lon": 0.0, "name": "Store 138"},
    140: {"lat": 0.0, "lon": 0.0, "name": "Store 140"},
    141: {"lat": 0.0, "lon": 0.0, "name": "Store 141"},
    142: {"lat": 0.0, "lon": 0.0, "name": "Store 142"},
    143: {"lat": 0.0, "lon": 0.0, "name": "Store 143"},
    144: {"lat": 0.0, "lon": 0.0, "name": "Store 144"},
    145: {"lat": 0.0, "lon": 0.0, "name": "Store 145"},
    146: {"lat": 0.0, "lon": 0.0, "name": "Store 146"},
    147: {"lat": 0.0, "lon": 0.0, "name": "Store 147"},
    148: {"lat": 0.0, "lon": 0.0, "name": "Store 148"},
    150: {"lat": 0.0, "lon": 0.0, "name": "Store 150"},
    151: {"lat": 0.0, "lon": 0.0, "name": "Store 151"},
    152: {"lat": 0.0, "lon": 0.0, "name": "Store 152"},
    153: {"lat": 0.0, "lon": 0.0, "name": "Store 153"},
    156: {"lat": 0.0, "lon": 0.0, "name": "Store 156"},
    157: {"lat": 0.0, "lon": 0.0, "name": "Store 157"},
    158: {"lat": 0.0, "lon": 0.0, "name": "Store 158"},
    159: {"lat": 0.0, "lon": 0.0, "name": "Store 159"},
    160: {"lat": 0.0, "lon": 0.0, "name": "Store 160"},
    161: {"lat": 0.0, "lon": 0.0, "name": "Store 161"},
    162: {"lat": 0.0, "lon": 0.0, "name": "Store 162"},
    163: {"lat": 0.0, "lon": 0.0, "name": "Store 163"},
    164: {"lat": 0.0, "lon": 0.0, "name": "Store 164"},
    165: {"lat": 0.0, "lon": 0.0, "name": "Store 165"},
    166: {"lat": 0.0, "lon": 0.0, "name": "Store 166"},
    167: {"lat": 0.0, "lon": 0.0, "name": "Store 167"},
    168: {"lat": 0.0, "lon": 0.0, "name": "Store 168"},
    169: {"lat": 0.0, "lon": 0.0, "name": "Store 169"},
    170: {"lat": 0.0, "lon": 0.0, "name": "Store 170"},
    177: {"lat": 0.0, "lon": 0.0, "name": "Store 177"},
    179: {"lat": 0.0, "lon": 0.0, "name": "Store 179"},
    189: {"lat": 0.0, "lon": 0.0, "name": "Store 189"},
}


def get_coords(loc_number: int) -> dict | None:
    """
    Return {"lat": float, "lon": float, "name": str} for a Loc Number.

    Returns None if:
      - the Loc Number is not in the table, OR
      - the entry still has placeholder coordinates (0.0, 0.0).

    When None is returned, the app will show a warning asking you to fill
    in the coordinates in this file.
    """
    entry = LOCATION_COORDS.get(loc_number)
    if entry is None:
        return None
    if entry["lat"] == _PLACEHOLDER_LAT and entry["lon"] == _PLACEHOLDER_LON:
        return None
    return entry
