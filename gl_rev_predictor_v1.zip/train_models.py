"""
train_models.py
---------------
Train all models on the same data split and save artifacts to disk.
Run once before launching app.py:

    python train_models.py

Produces:
    lgbm_gl_rev_model.txt          (LightGBM native text format)
    linreg_gl_rev_model.joblib     (sklearn Pipeline: OHE + LinearRegression)
"""

import pandas as pd
import numpy as np
import joblib
import lightgbm as lgb
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings

warnings.filterwarnings("ignore")

# Import shared constants (single source of truth)
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from features import VALID_LOC_NUMBERS, FEATURES, TARGET

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE_DIR   = os.path.dirname(__file__)
FILE_PATH  = os.path.join(BASE_DIR, "20260202 Walk in sales - v1400.xlsx")
LGBM_PATH  = os.path.join(BASE_DIR, "lgbm_gl_rev_model.txt")
LINREG_PATH = os.path.join(BASE_DIR, "linreg_gl_rev_model.joblib")

# ---------------------------------------------------------------------------
# 1. Load and clean data
# ---------------------------------------------------------------------------

print("=" * 60)
print("Loading data...")
# If the file is locked (e.g. open in Excel), copy it to a temp path first
import shutil, tempfile
try:
    df = pd.read_excel(FILE_PATH, sheet_name="Model Data")
except PermissionError:
    tmp = os.path.join(tempfile.gettempdir(), "capstone_data_copy.xlsx")
    shutil.copy2(FILE_PATH, tmp)
    print(f"  (File locked — using temp copy at {tmp})")
    df = pd.read_excel(tmp, sheet_name="Model Data")
df = df.dropna(subset=[TARGET])
print(f"  {len(df):,} rows, {df['Loc Number'].nunique()} unique locations")

# ---------------------------------------------------------------------------
# 2. Shared calendar features
# ---------------------------------------------------------------------------

df["Date"]       = pd.to_datetime(df["Date"])
df["DayOfWeek"]  = df["Date"].dt.dayofweek
df["Month"]      = df["Date"].dt.month
df["DayOfMonth"] = df["Date"].dt.day
df["WeekOfYear"] = df["Date"].dt.isocalendar().week.astype(int)
df["IsWeekend"]  = (df["DayOfWeek"] >= 5).astype(int)
df["Quarter"]    = df["Date"].dt.quarter

# ---------------------------------------------------------------------------
# 3. Time-based train / test split (identical for both models)
# ---------------------------------------------------------------------------

cutoff     = df["Date"].quantile(0.80)
train_mask = df["Date"] <= cutoff
test_mask  = df["Date"] >  cutoff

print(f"\nTrain: {train_mask.sum():,} rows  "
      f"({df.loc[train_mask, 'Date'].min().date()} to {df.loc[train_mask, 'Date'].max().date()})")
print(f"Test:  {test_mask.sum():,} rows  "
      f"({df.loc[test_mask, 'Date'].min().date()} to {df.loc[test_mask, 'Date'].max().date()})")

y      = df[TARGET]
y_tr   = y[train_mask]
y_te   = y[test_mask]

# ---------------------------------------------------------------------------
# 4. LightGBM
# ---------------------------------------------------------------------------

print("\n" + "=" * 60)
print("Training LightGBM...")

df_lgbm = df.copy()
df_lgbm["Loc Number"] = pd.Categorical(
    df_lgbm["Loc Number"], categories=VALID_LOC_NUMBERS
)

X_lgbm    = df_lgbm[FEATURES]
X_tr_lgbm = X_lgbm[train_mask]
X_te_lgbm = X_lgbm[test_mask]

lgbm_params = {
    "objective":         "regression",
    "metric":            ["mae", "rmse"],
    "boosting_type":     "gbdt",
    "num_leaves":        63,
    "learning_rate":     0.05,
    "feature_fraction":  0.8,
    "bagging_fraction":  0.8,
    "bagging_freq":      5,
    "min_child_samples": 20,
    "lambda_l1":         0.1,
    "lambda_l2":         0.1,
    "verbose":           -1,
    "n_jobs":            -1,
    "seed":              42,
}

train_ds = lgb.Dataset(
    X_tr_lgbm, label=y_tr,
    categorical_feature=["Loc Number"],
    free_raw_data=False,
)
test_ds = lgb.Dataset(
    X_te_lgbm, label=y_te,
    reference=train_ds,
    free_raw_data=False,
)

lgbm_model = lgb.train(
    lgbm_params,
    train_ds,
    num_boost_round=1000,
    valid_sets=[train_ds, test_ds],
    valid_names=["train", "test"],
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=100),
    ],
)

lgbm_preds = lgbm_model.predict(X_te_lgbm, num_iteration=lgbm_model.best_iteration)
lgbm_mae   = mean_absolute_error(y_te, lgbm_preds)
lgbm_rmse  = np.sqrt(mean_squared_error(y_te, lgbm_preds))
lgbm_r2    = r2_score(y_te, lgbm_preds)

print(f"  Best iteration : {lgbm_model.best_iteration}")
print(f"  MAE            : ${lgbm_mae:>12,.2f}")
print(f"  RMSE           : ${lgbm_rmse:>12,.2f}")
print(f"  R2             :  {lgbm_r2:>12.4f}")

lgbm_model.save_model(LGBM_PATH)
print(f"  Saved: {LGBM_PATH}")

# ---------------------------------------------------------------------------
# 5. Linear Regression (Pipeline: OHE + LinearRegression)
# ---------------------------------------------------------------------------

print("\n" + "=" * 60)
print("Training Linear Regression...")

df_lr = df.copy()
df_lr["Loc Number"] = df_lr["Loc Number"].astype(int)

X_lr    = df_lr[FEATURES]
X_tr_lr = X_lr[train_mask]
X_te_lr = X_lr[test_mask]

numeric_cols = [f for f in FEATURES if f != "Loc Number"]
cat_cols     = ["Loc Number"]

preprocessor = ColumnTransformer(
    transformers=[
        (
            "ohe",
            OneHotEncoder(
                categories=[VALID_LOC_NUMBERS],
                sparse_output=False,
                handle_unknown="ignore",   # unseen loc -> all-zero row (safety net)
            ),
            cat_cols,
        ),
        ("num", "passthrough", numeric_cols),
    ],
    remainder="drop",
)

linreg_pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor",    LinearRegression(n_jobs=-1)),
])

linreg_pipeline.fit(X_tr_lr, y_tr)

lr_preds = linreg_pipeline.predict(X_te_lr)
lr_mae   = mean_absolute_error(y_te, lr_preds)
lr_rmse  = np.sqrt(mean_squared_error(y_te, lr_preds))
lr_r2    = r2_score(y_te, lr_preds)

print(f"  MAE  : ${lr_mae:>12,.2f}")
print(f"  RMSE : ${lr_rmse:>12,.2f}")
print(f"  R2   :  {lr_r2:>12.4f}")

joblib.dump(linreg_pipeline, LINREG_PATH)
print(f"  Saved: {LINREG_PATH}")

# ---------------------------------------------------------------------------
# 6. Side-by-side comparison
# ---------------------------------------------------------------------------

print("\n" + "=" * 60)
print("Model comparison on test set:")
print(f"  {'Metric':<8}  {'LightGBM':>14}  {'Linear Reg':>14}")
print(f"  {'-'*8}  {'-'*14}  {'-'*14}")
print(f"  {'MAE':<8}  ${lgbm_mae:>13,.2f}  ${lr_mae:>13,.2f}")
print(f"  {'RMSE':<8}  ${lgbm_rmse:>13,.2f}  ${lr_rmse:>13,.2f}")
print(f"  {'R2':<8}  {lgbm_r2:>14.4f}  {lr_r2:>14.4f}")
print("=" * 60)
print("All models trained and saved.")
