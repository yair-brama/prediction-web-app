"""
features.py
-----------
Single source of truth for constants and feature engineering.
Imported by app.py, model_registry.py, and train_models.py.
"""

import pandas as pd

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FEATURES = [
    "Precipitation",
    "DayOfWeek",
    "Month",
    "DayOfMonth",
    "WeekOfYear",
    "IsWeekend",
    "Quarter",
    "Loc Number",
]

TARGET = "GL Rev"

# All unique Loc Numbers present in the training data (sorted ascending)
VALID_LOC_NUMBERS = [
    4, 5, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 38, 39, 42, 43, 44, 45, 47,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 66,
    67, 68, 69, 70, 71, 72, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84,
    85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101,
    102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115,
    116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130,
    131, 132, 133, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145,
    146, 147, 148, 150, 151, 152, 153, 156, 157, 158, 159, 160, 161, 162,
    163, 164, 165, 166, 167, 168, 169, 170, 177, 179, 189,
]

MAX_PRECIPITATION = 782.49  # max value seen during training

# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add all calendar-derived columns to a copy of df."""
    out = df.copy()
    out["Date"] = pd.to_datetime(out["Date"])
    out["DayOfWeek"]  = out["Date"].dt.dayofweek
    out["Month"]      = out["Date"].dt.month
    out["DayOfMonth"] = out["Date"].dt.day
    out["WeekOfYear"] = out["Date"].dt.isocalendar().week.astype(int)
    out["IsWeekend"]  = (out["DayOfWeek"] >= 5).astype(int)
    out["Quarter"]    = out["Date"].dt.quarter
    return out


def _validate_loc_numbers(df: pd.DataFrame) -> None:
    """Raise ValueError if any Loc Number was not seen during training."""
    invalid = set(df["Loc Number"].unique()) - set(VALID_LOC_NUMBERS)
    if invalid:
        raise ValueError(
            f"Loc Number value(s) not seen during training: {sorted(invalid)}. "
            f"Valid values are integers in: {VALID_LOC_NUMBERS}"
        )

# ---------------------------------------------------------------------------
# Public feature engineering functions
# ---------------------------------------------------------------------------

def engineer_features_lgbm(df: pd.DataFrame) -> pd.DataFrame:
    """
    Feature engineering for LightGBM.
    Loc Number is encoded as pd.Categorical with explicit categories matching
    the training-time encoding, so category codes are identical at inference.

    Input:  DataFrame with columns [Loc Number (int), Date (datetime-like), Precipitation (float)]
    Output: DataFrame with exactly FEATURES columns in correct order and dtypes.
    """
    out = _add_calendar_features(df)
    _validate_loc_numbers(out)
    out["Loc Number"] = pd.Categorical(
        out["Loc Number"],
        categories=VALID_LOC_NUMBERS,
    )
    return out[FEATURES]


def engineer_features_sklearn(df: pd.DataFrame) -> pd.DataFrame:
    """
    Feature engineering for scikit-learn models.
    Loc Number is kept as plain int; the Pipeline's ColumnTransformer +
    OneHotEncoder (fit with categories=VALID_LOC_NUMBERS) handles encoding.

    Input:  DataFrame with columns [Loc Number (int), Date (datetime-like), Precipitation (float)]
    Output: DataFrame with exactly FEATURES columns in correct order and dtypes.
    """
    out = _add_calendar_features(df)
    _validate_loc_numbers(out)
    out["Loc Number"] = out["Loc Number"].astype(int)
    return out[FEATURES]
