# -*- coding: utf-8 -*-
"""
GL Rev Predictor - Streamlit inference app
Supports multiple model backends via model_registry.py.
Precipitation can be auto-fetched from Open-Meteo (weather.py).
"""

import streamlit as st
import pandas as pd
import numpy as np
import datetime
import sys
import os

# Ensure the Capstone directory is on the path so local modules are importable
sys.path.insert(0, os.path.dirname(__file__))

from features import VALID_LOC_NUMBERS, MAX_PRECIPITATION, FEATURES
from model_registry import MODEL_REGISTRY, MODEL_DISPLAY_ORDER
from location_coords import get_coords
from weather import get_precipitation

# ---------------------------------------------------------------------------
# Page config (must be the first Streamlit call)
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="GL Rev Predictor",
    page_icon="💰",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Model loading (cached per model_key)
# ---------------------------------------------------------------------------

@st.cache_resource
def load_model(model_key: str):
    """Load and cache a model by its registry key. Called once per key."""
    wrapper = MODEL_REGISTRY[model_key]
    return wrapper.load_fn(wrapper.model_file)


# Preload all registered models at startup
loaded_models: dict = {}
for _key in MODEL_DISPLAY_ORDER:
    _wrapper = MODEL_REGISTRY[_key]
    if not _wrapper.exists:
        st.error(
            f"**Model artifact not found:** `{_wrapper.model_file}`\n\n"
            f"Run `python train_models.py` to generate all model files, "
            f"then restart the app."
        )
        st.stop()
    try:
        loaded_models[_key] = load_model(_key)
    except Exception as e:
        st.error(
            f"**Could not load '{_wrapper.display_name}'**\n\n"
            f"File: `{_wrapper.model_file}`\n\nError: {e}"
        )
        st.stop()

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def build_raw_row(
    loc_number: int,
    input_date: datetime.date,
    precipitation: float,
) -> pd.DataFrame:
    """Build a one-row raw DataFrame from manual entry inputs."""
    return pd.DataFrame({
        "Loc Number":    [loc_number],
        "Date":          [pd.Timestamp(input_date)],
        "Precipitation": [precipitation],
    })


def parse_uploaded_file(uploaded_file, require_precipitation: bool = True):
    """
    Read a CSV or Excel upload and validate it.
    Returns (df, errors) where errors is a list of strings.

    When require_precipitation=False, the Precipitation column is optional.
    Missing or blank values are allowed (stored as NaN) so the caller can
    offer to auto-fill them from the weather API.
    """
    errors = []
    name = uploaded_file.name.lower()

    try:
        if name.endswith(".csv"):
            df = pd.read_csv(uploaded_file)
        elif name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(uploaded_file)
        else:
            return None, ["Unsupported file type. Please upload a CSV or Excel file."]
    except Exception as e:
        return None, [f"Could not read file: {e}"]

    if len(df) == 0:
        return None, ["The uploaded file contains no data rows."]

    # Precipitation is conditionally required
    required = {"Loc Number", "Date"} if not require_precipitation else {"Loc Number", "Date", "Precipitation"}
    missing = required - set(df.columns)
    if missing:
        errors.append(f"Missing required column(s): {', '.join(sorted(missing))}")
        return None, errors

    # If Precipitation column is absent entirely, add it as NaN
    if "Precipitation" not in df.columns:
        df["Precipitation"] = float("nan")

    # Coerce Loc Number to int (CSV may produce 42.0)
    try:
        df["Loc Number"] = df["Loc Number"].astype(float).astype(int)
    except (ValueError, TypeError):
        errors.append(
            "'Loc Number' column contains non-numeric values. "
            "It must contain integers (e.g. 42)."
        )

    # Coerce Precipitation to float; allow NaN when not required
    if require_precipitation:
        try:
            df["Precipitation"] = pd.to_numeric(df["Precipitation"], errors="raise")
        except (ValueError, TypeError):
            errors.append(
                "'Precipitation' column contains non-numeric values. "
                "It must contain numbers (e.g. 0.25)."
            )
    else:
        df["Precipitation"] = pd.to_numeric(df["Precipitation"], errors="coerce")

    # Parse dates
    parsed_dates = pd.to_datetime(df["Date"], errors="coerce")
    bad = parsed_dates.isna().sum()
    if bad > 0:
        errors.append(
            f"'Date' column has {bad} row(s) that could not be parsed. "
            "Use format YYYY-MM-DD (e.g. 2024-03-15)."
        )
    else:
        df["Date"] = parsed_dates

    # Validate loc numbers (only if no prior issues with that column)
    if not any("Loc Number" in e for e in errors):
        invalid_locs = set(df["Loc Number"].unique()) - set(VALID_LOC_NUMBERS)
        if invalid_locs:
            errors.append(
                f"Loc Number value(s) not seen during training: {sorted(invalid_locs)}."
            )

    # Negative precipitation check (skip NaN rows when not required)
    if not any("Precipitation" in e for e in errors):
        filled = df["Precipitation"].dropna() if not require_precipitation else df["Precipitation"]
        neg = (filled < 0).sum()
        if neg > 0:
            errors.append(
                f"'Precipitation' column has {neg} negative value(s). Must be >= 0."
            )

    if errors:
        return None, errors

    return df, []


def format_results(raw_df: pd.DataFrame, predictions: np.ndarray) -> pd.DataFrame:
    """Combine original input columns with predictions."""
    result = raw_df[["Loc Number", "Date", "Precipitation"]].copy()
    result["Predicted GL Rev"] = predictions
    result["Date"] = pd.to_datetime(result["Date"]).dt.date
    return result


def convert_df_to_csv(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def _do_autofill(loc_number: int, input_date: datetime.date, prefill_key: str):
    """
    Shared auto-fill logic: fetch precipitation for a location+date and
    store the result in session_state under prefill_key, then rerun.
    Displays warnings/errors inline on failure.
    Returns True if a rerun was triggered, False otherwise.
    """
    coords = get_coords(loc_number)
    if coords is None:
        st.warning(
            f"No coordinates configured for Location **{loc_number}**. "
            "Edit `location_coords.py` to enable weather auto-fill.",
            icon="⚠️",
        )
        return False

    with st.spinner(f"Fetching precipitation for {coords['name']} on {input_date}..."):
        result = get_precipitation(coords["lat"], coords["lon"], input_date)

    if result is None:
        st.error(
            "Could not retrieve weather data from Open-Meteo. "
            "Check your network connection or try a different date.",
            icon="🌐",
        )
        return False

    st.session_state[prefill_key] = result
    st.rerun()
    return True  # unreachable after rerun, but keeps linters happy


# ---------------------------------------------------------------------------
# App header
# ---------------------------------------------------------------------------

st.title("GL Revenue Predictor")
st.markdown(
    "Predict **GL Revenue** for any location by providing the date and "
    "forecasted precipitation. Select a model in the sidebar, then choose "
    "**Manual Entry** for a single prediction or **File Upload** for batch predictions."
)
st.divider()

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    # --- Model selector ---
    st.header("Model")
    selected_key = st.radio(
        "Choose prediction model:",
        options=MODEL_DISPLAY_ORDER,
        format_func=lambda k: MODEL_REGISTRY[k].display_name,
        index=0,
    )

    active_wrapper = MODEL_REGISTRY[selected_key]
    active_model   = loaded_models[selected_key]

    if active_wrapper.description:
        st.caption(active_wrapper.description)

    st.divider()

    # --- Prediction mode ---
    st.header("Prediction Mode")
    mode = st.radio(
        "Choose input method:",
        options=["Manual Entry", "File Upload", "Model Comparison"],
        index=0,
    )

    st.divider()
    st.caption(f"Model file: `{active_wrapper.filename}`")
    st.caption(f"Locations available: {len(VALID_LOC_NUMBERS)}")

# ---------------------------------------------------------------------------
# Manual Entry
# ---------------------------------------------------------------------------

if mode == "Manual Entry":
    st.subheader(f"Single Prediction — {active_wrapper.display_name}")

    # Pre-fill staging: consume the staging key written by the auto-fill button
    # on the previous rerun and inject it as the number_input's starting value.
    _ME_PREFILL = "_me_precip_prefill"
    _me_precip_start = float(st.session_state.pop(_ME_PREFILL, 0.0))

    col1, col2, col3 = st.columns(3)
    with col1:
        loc_number = st.selectbox(
            "Location Number",
            options=VALID_LOC_NUMBERS,
            index=0,
            key="me_loc",
            help="Select from the 153 known store location IDs.",
        )
    with col2:
        input_date = st.date_input(
            "Date",
            value=datetime.date.today(),
            key="me_date",
            help="Date for which to predict GL Revenue.",
        )
    with col3:
        precipitation = st.number_input(
            "Precipitation (inches)",
            min_value=0.0,
            max_value=1000.0,
            value=_me_precip_start,
            step=0.01,
            format="%.2f",
            key="me_precip",
            help="Forecasted daily precipitation in inches.",
        )

    # Auto-fill button row
    autofill_col, predict_col, _ = st.columns([2, 1, 2])
    with autofill_col:
        if st.button(
            "Auto-fill Precipitation from Weather",
            key="me_autofill_btn",
            help="Fetches forecasted or historical daily precipitation "
                 "for this location and date from Open-Meteo (free, no key needed).",
        ):
            _do_autofill(loc_number, input_date, _ME_PREFILL)

    with predict_col:
        predict_clicked = st.button("Predict", type="primary", key="me_predict_btn")

    if precipitation > MAX_PRECIPITATION:
        st.warning(
            f"Precipitation ({precipitation:.2f} in) exceeds the training maximum "
            f"({MAX_PRECIPITATION:.2f} in). The prediction may be less reliable."
        )

    if predict_clicked:
        try:
            raw_df = build_raw_row(loc_number, input_date, precipitation)
            preds  = active_wrapper.predict(raw_df, active_model)
            val    = preds[0]

            st.divider()
            st.subheader("Prediction Result")
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.metric("Location", str(loc_number))
            with c2:
                st.metric("Date", str(input_date))
            with c3:
                st.metric("Precipitation", f"{precipitation:.2f} in")
            with c4:
                st.metric(f"Predicted GL Rev ({active_wrapper.display_name})", f"${val:,.2f}")

        except ValueError as ve:
            st.error(str(ve))
        except Exception as e:
            st.error(f"Prediction failed: {e}")

# ---------------------------------------------------------------------------
# File Upload
# ---------------------------------------------------------------------------

elif mode == "File Upload":
    st.subheader(f"Batch Prediction — {active_wrapper.display_name}")

    col_a, col_b = st.columns([1, 1])
    with col_a:
        st.markdown(
            """
**Required columns:**

| Column | Type | Example |
|---|---|---|
| `Loc Number` | Integer | `42` |
| `Date` | Date (YYYY-MM-DD) | `2024-03-15` |
| `Precipitation` | Float >= 0 *(optional — can be auto-filled)* | `0.25` |

Extra columns are ignored.
            """
        )
    with col_b:
        sample_df = pd.DataFrame({
            "Loc Number":    [10, 14, 56],
            "Date":          ["2025-06-01", "2025-06-01", "2025-06-02"],
            "Precipitation": [0.00, 0.15, 1.20],
        })
        st.info(
            "The **Precipitation** column is now optional. "
            "If missing or blank, you can auto-fill it from Open-Meteo after uploading.",
            icon="🌧️",
        )
        st.download_button(
            label="Download Sample Template",
            data=convert_df_to_csv(sample_df),
            file_name="inference_template.csv",
            mime="text/csv",
        )

    st.divider()

    uploaded_file = st.file_uploader(
        "Upload your inference file",
        type=["csv", "xlsx", "xls"],
    )

    if uploaded_file is not None:
        # Parse without requiring Precipitation so we can offer to auto-fill it
        raw_df, errors = parse_uploaded_file(uploaded_file, require_precipitation=False)

        if errors:
            for err in errors:
                st.error(err)
            st.stop()

        # Restore a partially auto-filled df from a previous rerun if present
        if "_upload_df" in st.session_state:
            raw_df = st.session_state.pop("_upload_df")

        # ---------- Auto-fill offer ----------
        missing_mask  = raw_df["Precipitation"].isna()
        missing_count = missing_mask.sum()

        if missing_count > 0:
            st.info(
                f"**{missing_count} row(s)** have missing Precipitation values. "
                "Click the button below to auto-fill them from Open-Meteo.",
                icon="🌧️",
            )
            if st.button(
                f"Auto-fill {missing_count} Missing Precipitation Value(s)",
                key="upload_autofill_btn",
            ):
                filled_count = 0
                unknown_locs = set()
                failed_rows  = []

                progress = st.progress(0, text="Fetching weather data...")
                missing_indices = raw_df[missing_mask].index.tolist()

                for i, idx in enumerate(missing_indices):
                    row    = raw_df.loc[idx]
                    loc    = int(row["Loc Number"])
                    date   = row["Date"].date() if hasattr(row["Date"], "date") else row["Date"]
                    coords = get_coords(loc)

                    if coords is None:
                        unknown_locs.add(loc)
                        failed_rows.append(idx)
                    else:
                        result = get_precipitation(coords["lat"], coords["lon"], date)
                        if result is not None:
                            raw_df.at[idx, "Precipitation"] = result
                            filled_count += 1
                        else:
                            failed_rows.append(idx)

                    progress.progress(
                        (i + 1) / len(missing_indices),
                        text=f"Fetched {i + 1} of {len(missing_indices)} rows...",
                    )

                progress.empty()

                if unknown_locs:
                    st.warning(
                        f"No coordinates configured for location(s): "
                        f"**{sorted(unknown_locs)}**. "
                        "Edit `location_coords.py` to enable auto-fill for these stores.",
                        icon="⚠️",
                    )
                if filled_count > 0:
                    st.success(
                        f"Auto-filled precipitation for **{filled_count}** row(s)."
                    )
                if len(failed_rows) - len(unknown_locs) > 0:
                    st.warning(
                        f"{len(failed_rows) - len(unknown_locs)} row(s) could not be "
                        "fetched (network error or date out of range).",
                        icon="🌐",
                    )

                # Persist modified df across the rerun triggered by button click
                st.session_state["_upload_df"] = raw_df
                st.rerun()

        # Drop any rows still missing Precipitation after auto-fill
        still_missing = raw_df["Precipitation"].isna().sum()
        if still_missing > 0:
            st.warning(
                f"{still_missing} row(s) still have missing Precipitation values "
                "and will be excluded from predictions.",
                icon="⚠️",
            )
            raw_df = raw_df.dropna(subset=["Precipitation"])

        if len(raw_df) == 0:
            st.error("No rows remain after removing rows with missing Precipitation.")
            st.stop()

        # ---------- Predict ----------
        try:
            preds = active_wrapper.predict(raw_df, active_model)
        except ValueError as ve:
            st.error(str(ve))
            st.stop()
        except Exception as e:
            st.error(f"Prediction failed: {e}")
            st.stop()

        results_df = format_results(raw_df, preds)

        st.success(
            f"Predicted GL Revenue for **{len(results_df):,} row(s)** "
            f"using **{active_wrapper.display_name}**."
        )

        # Results table
        st.subheader("Prediction Results")
        display_df = results_df.copy()
        display_df["Predicted GL Rev"] = display_df["Predicted GL Rev"].apply(
            lambda x: f"${x:,.2f}"
        )
        st.dataframe(display_df, use_container_width=True, hide_index=True)

        # Bar chart
        st.subheader("Predicted GL Rev by Location")
        chart_df = (
            results_df.groupby("Loc Number")["Predicted GL Rev"]
            .mean()
            .reset_index()
            .sort_values("Predicted GL Rev", ascending=False)
            .set_index("Loc Number")
        )
        if len(chart_df) > 1:
            st.bar_chart(chart_df, y="Predicted GL Rev", use_container_width=True)
            if len(results_df) > len(chart_df):
                st.caption("Chart shows mean predicted GL Rev per location.")
        else:
            st.info("Upload data for more than one location to see a comparison chart.")

        # Download
        st.divider()
        st.download_button(
            label="Download Results as CSV",
            data=convert_df_to_csv(results_df),
            file_name="gl_rev_predictions.csv",
            mime="text/csv",
            type="primary",
        )

# ---------------------------------------------------------------------------
# Model Comparison
# ---------------------------------------------------------------------------

elif mode == "Model Comparison":
    st.subheader("Model Comparison — Side by Side")
    st.markdown(
        "Enter inputs once and see predictions from **all available models** simultaneously."
    )

    # Pre-fill staging for the comparison panel
    _CMP_PREFILL = "_cmp_precip_prefill"
    _cmp_precip_start = float(st.session_state.pop(_CMP_PREFILL, 0.0))

    col1, col2, col3 = st.columns(3)
    with col1:
        cmp_loc = st.selectbox(
            "Location Number",
            options=VALID_LOC_NUMBERS,
            index=0,
            key="cmp_loc",
        )
    with col2:
        cmp_date = st.date_input(
            "Date",
            value=datetime.date.today(),
            key="cmp_date",
        )
    with col3:
        cmp_precip = st.number_input(
            "Precipitation (inches)",
            min_value=0.0,
            max_value=1000.0,
            value=_cmp_precip_start,
            step=0.01,
            format="%.2f",
            key="cmp_precip",
        )

    # Auto-fill + Compare buttons on the same row
    autofill_col, compare_col, _ = st.columns([2, 1, 2])
    with autofill_col:
        if st.button(
            "Auto-fill Precipitation from Weather",
            key="cmp_autofill_btn",
            help="Fetches forecasted or historical daily precipitation "
                 "for this location and date from Open-Meteo.",
        ):
            _do_autofill(cmp_loc, cmp_date, _CMP_PREFILL)

    with compare_col:
        compare_clicked = st.button("Compare All Models", type="primary", key="cmp_compare_btn")

    if compare_clicked:
        raw_df = build_raw_row(cmp_loc, cmp_date, cmp_precip)

        st.divider()
        st.subheader("Results")

        results = {}
        cmp_errors = []
        for key in MODEL_DISPLAY_ORDER:
            wrapper = MODEL_REGISTRY[key]
            try:
                pred = wrapper.predict(raw_df, loaded_models[key])
                results[key] = pred[0]
            except Exception as e:
                cmp_errors.append(f"{wrapper.display_name}: {e}")

        if cmp_errors:
            for err in cmp_errors:
                st.error(err)

        if results:
            cols = st.columns(len(results))
            for col, (key, val) in zip(cols, results.items()):
                wrapper = MODEL_REGISTRY[key]
                with col:
                    st.metric(label=wrapper.display_name, value=f"${val:,.2f}")

            if len(results) == 2:
                keys = list(results.keys())
                diff = results[keys[0]] - results[keys[1]]
                pct  = (diff / results[keys[1]] * 100) if results[keys[1]] != 0 else 0
                st.markdown("---")
                st.markdown(
                    f"**Difference** ({MODEL_REGISTRY[keys[0]].display_name} vs "
                    f"{MODEL_REGISTRY[keys[1]].display_name}): "
                    f"**${diff:+,.2f}** ({pct:+.1f}%)"
                )

            summary = pd.DataFrame([
                {
                    "Model": MODEL_REGISTRY[k].display_name,
                    "Predicted GL Rev": f"${v:,.2f}",
                }
                for k, v in results.items()
            ])
            st.dataframe(summary, use_container_width=False, hide_index=True)
